﻿using System;

class PhanSo
{
    public int TuSo { get; set; }
    public int MauSo { get; set; }

    public PhanSo(int tu, int mau)
    {
        TuSo = tu;
        MauSo = mau;
    }

    public static PhanSo operator +(PhanSo a, PhanSo b)
    {
        int tu = a.TuSo * b.MauSo + b.TuSo * a.MauSo;
        int mau = a.MauSo * b.MauSo;
        return new PhanSo(tu, mau);
    }

    public static PhanSo operator -(PhanSo a, PhanSo b)
    {
        int tu = a.TuSo * b.MauSo - b.TuSo * a.MauSo;
        int mau = a.MauSo * b.MauSo;
        return new PhanSo(tu, mau);
    }

    public static PhanSo operator *(PhanSo a, PhanSo b)
    {
        return new PhanSo(a.TuSo * b.TuSo, a.MauSo * b.MauSo);
    }

    public static PhanSo operator /(PhanSo a, PhanSo b)
    {
        return new PhanSo(a.TuSo * b.MauSo, a.MauSo * b.TuSo);
    }

    public void HienThi()
    {
        Console.WriteLine($"{TuSo}/{MauSo}");
    }
}