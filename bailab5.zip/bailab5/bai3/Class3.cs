﻿using System;
using System.Collections.Generic;

class HoaDon
{
    public KhachHang kh;
    public List<HangHoa> dsHang = new List<HangHoa>();

    public HoaDon(KhachHang k)
    {
        kh = k;
    }

    public void ThemHang(HangHoa h)
    {
        dsHang.Add(h);
    }

    public void XoaHang(string ma)
    {
        dsHang.RemoveAll(h => h.MaHH == ma);
    }

    public HangHoa TimGiaCaoNhat()
    {
        HangHoa max = dsHang[0];
        foreach (var h in dsHang)
        {
            if (h.DonGia > max.DonGia)
                max = h;
        }
        return max;
    }

    public void InHoaDon()
    {
        Console.WriteLine("===== HOA DON =====");
        kh.HienThi();
        Console.WriteLine("Danh sach hang:");
        foreach (var h in dsHang)
        {
            h.HienThi();
        }
    }
}