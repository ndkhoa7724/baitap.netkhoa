﻿using System;

class KhachHang
{
    public string MaKH { get; set; }
    public string TenKH { get; set; }
    public string DiaChi { get; set; }

    public KhachHang(string ma, string ten, string dc)
    {
        MaKH = ma;
        TenKH = ten;
        DiaChi = dc;
    }

    public void HienThi()
    {
        Console.WriteLine($"{MaKH} - {TenKH} - {DiaChi}");
    }
}