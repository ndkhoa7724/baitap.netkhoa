﻿using System;

class Program
{
    static void Main(string[] args)
    {
        KhachHang kh = new KhachHang("KH01", "Nguyen Van A", "Ha Noi");
        HoaDon hd = new HoaDon(kh);

        HangHoa h1 = new HangHoa("H1", "Laptop", 1500);
        HangHoa h2 = new HangHoa("H2", "Mouse", 20);
        HangHoa h3 = new HangHoa("H3", "Keyboard", 50);

        hd.ThemHang(h1);
        hd.ThemHang(h2);
        hd.ThemHang(h3);

        hd.InHoaDon();

        Console.WriteLine("Hang gia cao nhat:");
        hd.TimGiaCaoNhat().HienThi();
    }
}