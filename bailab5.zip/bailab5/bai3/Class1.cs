﻿using System;

class HangHoa
{
    public string MaHH { get; set; }
    public string TenHH { get; set; }
    public double DonGia { get; set; }

    public HangHoa(string ma, string ten, double gia)
    {
        MaHH = ma;
        TenHH = ten;
        DonGia = gia;
    }

    public void HienThi()
    {
        Console.WriteLine($"{MaHH} - {TenHH} - {DonGia}");
    }
}