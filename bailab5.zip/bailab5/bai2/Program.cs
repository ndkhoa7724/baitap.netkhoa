﻿using System;

class So
{
    public int GiaTri { get; set; }

    public So(int x)
    {
        GiaTri = x;
    }

    public static So operator +(So a, So b)
    {
        return new So(a.GiaTri + b.GiaTri);
    }

    public static So operator -(So a, So b)
    {
        return new So(a.GiaTri - b.GiaTri);
    }

    public static So operator *(So a, So b)
    {
        return new So(a.GiaTri * b.GiaTri);
    }

    public static So operator /(So a, So b)
    {
        return new So(a.GiaTri / b.GiaTri);
    }

    public bool LaSoChan()
    {
        return GiaTri % 2 == 0;
    }

    public bool LaSoLe()
    {
        return GiaTri % 2 != 0;
    }

    public bool LaSoNguyenTo()
    {
        if (GiaTri < 2) return false;
        for (int i = 2; i <= Math.Sqrt(GiaTri); i++)
            if (GiaTri % i == 0) return false;
        return true;
    }
}